# -*- coding: utf-8 -*-
"""
Created on Fri Dec 14 14:58:16 2018

@author: DISCOVER06
"""

import cv2 as cv
import numpy as np
import pytesseract
from sklearn.externals import joblib
import os
import re
from collections import Counter
import operator
from datetime import datetime
from shutil import copyfile
import _thread
import shutil
import pandas as pd
from collections import defaultdict

BASE_DIR = 'C:/TEMP/'
DIR_FILIAL = 'Digitalizado'
MAIN_DIR = BASE_DIR + '{0}/'.format(DIR_FILIAL)
TEMP_DIR = BASE_DIR + '/tmp/'
from glob import glob


class Proposta:

    def __init__(self, index):
        self.index = index
        self.directory = index
        self.files = []

    def set_numero(self, numero):
        self.numero = numero

    def set_data_vigencia(self, data_vigencia):
        self.data_vigencia = data_vigencia

    def set_ans(self, ans):
        self.ans = ans

    def set_filial(self, filial):
        self.filial = filial

    def add_numero(self, f):
        self.files.append(f)

    def get_info_capa(self):
        files_dir = os.listdir('C:/TEMP/tmp/{0}/'.format(self.directory))
        print(' TEMP_DIR + self.directory : ', TEMP_DIR + self.directory + '/' + files_dir[0])
        image = cv.imread(TEMP_DIR + self.directory + '/' + files_dir[0])
        image = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
        ocr = pytesseract.image_to_string(image)
        numbers = re.findall(r'\d+', ocr)
        if len(numbers) == 2:
            return numbers[0], numbers[1]
        return None, None

    def get_image_num_processo(image):

        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

        # binary

        image = cv.resize(image, (int(2480), int(3507)))
        #    image = image[:600,:]
        #    image = cv.pow(image, 0.6)
        #    image = cv.fastNlMeansDenoisingColored(img,None,10,10,7,21)

        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
        # binary
        res, thresh = cv.threshold(gray, 127, 255, cv.THRESH_BINARY_INV)
        kernel = np.ones((5, 25), np.int8)
        img_dilatation = cv.dilate(thresh, kernel, iterations=1)
        img2, ctrs, hier = cv.findContours(img_dilatation.copy(), cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
        ocr = pytesseract.image_to_string(image[:600, :])

        return ocr

    def get_image_num_processo(self, image):

        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

        # binary

        image = cv.resize(image, (int(2480), int(3507)))
        #    image = image[:600,:]
        #    image = cv.pow(image, 0.6)
        #    image = cv.fastNlMeansDenoisingColored(img,None,10,10,7,21)

        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
        # binary
        res, thresh = cv.threshold(gray, 127, 255, cv.THRESH_BINARY_INV)
        kernel = np.ones((5, 25), np.int8)
        img_dilatation = cv.dilate(thresh, kernel, iterations=1)
        img2, ctrs, hier = cv.findContours(img_dilatation.copy(), cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
        ocr = pytesseract.image_to_string(image[:600, :])

        return ocr

    def processa_proposta(self):
        possivel_numero_proposta = []
        numero_proposta = None
        print(' TEMP_DIR + self.directory ::::::::::::::::::::; ', TEMP_DIR + self.directory)
        for file in os.listdir(TEMP_DIR + self.directory):

            if numero_proposta == None:
                #            print(' directory + file ', TEMP_DIR + directory + '/' + file)
                ocr = self.get_image_num_processo(cv.imread(TEMP_DIR + self.directory + '/' + file))
                #            print(' ocr :: ', ocr)
                numbers = re.findall(r'\d+', ocr)
                numbers = list(filter(lambda x: x > 1000000, map(int, numbers)))
                possivel_numero_proposta = possivel_numero_proposta + numbers
                keys = list(Counter(possivel_numero_proposta).keys())
                values = list(Counter(possivel_numero_proposta).values())
                if len(keys) > 0:
                    #                print('values, keys :', values, keys)
                    index, value = max(enumerate(values), key=operator.itemgetter(1))
                    if value >= 3:
                        print('########', keys[index])
                        numero_proposta = keys[index]

            if numero_proposta is not None:
                break

        if numero_proposta is not None:
            self.numero = numero_proposta


class Propostas():

    def __init__(self):
        self.propostas = [];

    def process_images_same_proposta(self, index_proposta, images_proposta):
        drtr = '{0}'.format(TEMP_DIR)
        folder = '/{0}'.format(index_proposta)
        dir_proposta = drtr + folder
        if not os.path.exists(dir_proposta):
            os.makedirs(dir_proposta)
        index_proposta = index_proposta + 1
        for f in images_proposta:
            copyfile(MAIN_DIR + '{0}'.format(f), dir_proposta + '/' + f)

        return folder

    def isPagina(self, image):
        return image.shape[0] < 3600

    def process_split(self, index_proposta, images_proposta):
        folder = self.process_images_same_proposta(index_proposta, images_proposta)

    def has_logo(self, img_rgb):
        img_gray = cv.cvtColor(img_rgb, cv.COLOR_BGR2GRAY)
        template = cv.imread('C:/Users/discover06/workspace/newgrid/desktop/logo.png', 0)
        w, h = template.shape[::-1]

        res = cv.matchTemplate(img_gray, template, cv.TM_CCOEFF_NORMED)
        threshold = 0.8
        loc = np.where(res >= threshold)
        if len(loc) > 0 and len(loc[0]) > 0 and len(loc[1]) > 0:
            return True

        return False

    def make_propostas(self, get_index=0, use_thread=False):
        images_proposta = []
        index_proposta = 0
        files = os.listdir(MAIN_DIR)

        for index in range(0, len(files)):
            file = files[index]
            if index > 0:
                image = cv.imread(MAIN_DIR + file)
                if not self.isPagina(image):
                    if self.has_logo(image):
                        print(' index_proposta, images_proposta ', index_proposta, len(images_proposta))
                        t1 = datetime.now()
                        if index_proposta == 0:
                            self.process_split(index_proposta, images_proposta)
                        else:
                            try:
                                if use_thread:
                                    _thread.start_new_thread(self.process_split, (index_proposta, images_proposta,))
                                else:
                                    self.process_split(index_proposta, images_proposta)
                            except:
                                print("Error: unable to start thread")
                        images_proposta = []
                        index_proposta += 1
                        t2 = datetime.now()
                        delta = t2 - t1
                        print('time :: ', delta.total_seconds())
            if index + 1 == len(files):
                images_proposta.append(file)
                print(' index_proposta, images_proposta ', index_proposta, len(images_proposta))
                try:
                    if use_thread:
                        _thread.start_new_thread(self.process_split, (index_proposta, images_proposta,))
                    else:
                        self.process_split(index_proposta, images_proposta)
                except:
                    print("Error: unable to start thread")
            images_proposta.append(file)
        return index_proposta

    def get_propostas(self):
        propostas = []
        for d in os.listdir(TEMP_DIR):
            print(' d ', d)
            p = Proposta(index=d)
            ans, filial = p.get_info_capa()
            p.set_ans(ans)
            p.set_filial(filial)
            print('ans, filial ', ans, filial)
            p.processa_proposta()
            propostas.append(p)
        return propostas

