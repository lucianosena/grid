# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\discover06\workspace\newgrid\desktop\Main.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import os
import cv2 as cv
import numpy as np
from sklearn.externals import joblib
import cv2
import pytesseract
from PyQt5.QtCore import pyqtSlot
import ocr

class Proposta:

    def __init__(self, numero, dataVigencia, ans, filial):
        self.numero = numero
        self.dataVigencia = dataVigencia
        self.ans = ans
        self.filial = filial

    def exist(self):
        return self.dataVigencia != None

def consultaProposta(numero):
    if (numero == '11401363'):
        return Proposta(numero, None, None, None)
    return Proposta(numero, '21/09/2018', '417173', '0055')

DIR_FILIAL='147'
PKL_FILE = 'coordenadas_num_processo_1.pkl'

def get_features(cord):
    a = int(cord[2]) + int(cord[0])
    b = int(cord[3]) + int(cord[1])
    h = a * b
    return [cord[0],cord[1],cord[2],cord[3],a,b,h]

def getBaseDir():
    return 'C:/TEMP/{0}/'.format(DIR_FILIAL)

def getBaseDirOut():
    return 'C:/TEMP/out/'

def getBaseDirTmp(name):
    return 'C:/TEMP/tmp/{0}/'.format(name)

def get_image_num_processo(file):
    ocr = None
    image = cv.imread(getBaseDir() + file)

    gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

    # binary
    res, thresh = cv.threshold(gray, 127, 255, cv.THRESH_BINARY_INV)

    kernel = np.ones((5, 25), np.int8)

    img_dilatation = cv.dilate(thresh, kernel, iterations=1)

    img2, ctrs, hier = cv.findContours(img_dilatation.copy(), cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)

    sorted_ctrs = sorted(ctrs, key=lambda ctr: cv.boundingRect(ctr)[0])
    sorted_ctrs = ctrs

    for i, ctr in enumerate(sorted_ctrs):
        x, y, w, h = cv.boundingRect(ctr)

        if w < 50:
            continue

        model = joblib.load(PKL_FILE)

        pred = model.predict(np.array([get_features([x, y, h, w])]).astype(int))
        img = image[y:y+h,x:x+w]
#        cv.imwrite(getBaseDir() + '{0}-{1}.jpg'.format(pred[0], (x, y, h, w)), img)

        if pred[0] == 1:
            print('-' * 50)
            print('predict ---- ', pred[0])
            range = 10
            img = image[y-range:y+h+range,x-range:x+w+range]
            ocr = pytesseract.image_to_string(img)
            print('-' * 12, ocr)
            print('-' * 50)
            cv.imwrite(getBaseDirOut() + '{0}.jpg'.format((x, y, h, w)), img)

    return ocr if ocr != None else 'NaN'

def folha_divisao(file):
    return True;

class Ui_MainWindow(object):


    def __init__(self):
        if not os.path.exists(getBaseDirTmp('')):
            os.mkdir(getBaseDirTmp(''))
        self.propostas = []
        print('*' * 30)
        index = 1
        pages_check = 5
        dir_proposta = getBaseDirTmp('1')
        num_proposta = None
        ocr_proposta = []
        for f in os.listdir(getBaseDir()):
            if folha_divisao(f):
                ocr_proposta = []
                num_proposta = ''
                dir_proposta = getBaseDirTmp(str(index))
                if not os.path.exists(dir_proposta):
                    os.mkdir(dir_proposta)
            image = cv.imread(getBaseDir() + f)
            print(' dir_proposta + f :: ', dir_proposta + f)
            cv.imwrite(dir_proposta + f, image)

            if count_check < 3:
                ocr = get_image_num_processo(f)
                if num_proposta == None:
                    num_proposta = ocr
                if ocr == num_proposta:
                    count_check = count_check + 1
                self.propostas.append(ocr)
                print('ocr ::::: ', ocr)
            index = index + 1

        print(self.propostas)

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(694, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setGeometry(QtCore.QRect(0, 0, 691, 271))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setRowCount(len(self.propostas))

        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(0, 3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(1, 4, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(2, 0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(2, 1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(2, 2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(2, 3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setItem(2, 4, item)
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(10, 290, 239, 25))
        self.widget.setObjectName("widget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.widget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pushValidar = QtWidgets.QPushButton(self.widget)
        self.pushValidar.setObjectName("pushValidar")
        self.buttonGroup = QtWidgets.QButtonGroup(MainWindow)
        self.buttonGroup.setObjectName("buttonGroup")
        self.buttonGroup.addButton(self.pushValidar)
        self.horizontalLayout.addWidget(self.pushValidar)
        self.pushEnviar = QtWidgets.QPushButton(self.widget)
        self.pushEnviar.setObjectName("pushEnviar")
        self.buttonGroup.addButton(self.pushEnviar)
        self.horizontalLayout.addWidget(self.pushEnviar)
        self.pushCancelar = QtWidgets.QPushButton(self.widget)
        self.pushCancelar.setObjectName("pushCancelar")
        self.buttonGroup.addButton(self.pushCancelar)
        self.horizontalLayout.addWidget(self.pushCancelar)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 694, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def remover(self):
        print('PyQt5 Remover button click')

    def enviar(self):
        print('PyQt5 Enviar button click')

    def cancelar(self):
        print('PyQt5 Cancelar button click')

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        item = self.tableWidget.verticalHeaderItem(0)
        item.setText(_translate("MainWindow", "1"))
        item = self.tableWidget.verticalHeaderItem(1)
        item.setText(_translate("MainWindow", "2"))
        item = self.tableWidget.verticalHeaderItem(2)
        item.setText(_translate("MainWindow", "3"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Proposta"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Data Vigência"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "ANS"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "Filial"))
        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        line = 0
        print('len', '-' * 30, len(self.propostas))
        for p in self.propostas:
            proposta = consultaProposta(p)
            if proposta.exist():
                item = self.tableWidget.item(line, 0)
                item.setText(_translate("MainWindow" , proposta.numero))
                item = self.tableWidget.item(line, 1)
                item.setText(_translate("MainWindow" , proposta.dataVigencia))
                item = self.tableWidget.item(line, 2)
                item.setText(_translate("MainWindow" , proposta.ans))
                item = self.tableWidget.item(line, 3)
                item.setText(_translate("MainWindow" , proposta.filial))

                if not os.path.exists(getBaseDir() + p):
                    os.mkdir(getBaseDir() + p)


            else:
                item = self.tableWidget.item(line, 0)
                item.setText(_translate("MainWindow", proposta.numero))
                item.setBackground(QtGui.QColor('red'))
                item = self.tableWidget.item(line, 1)
                item.setText(_translate("MainWindow", proposta.dataVigencia))
                item.setBackground(QtGui.QColor('red'))
                item = self.tableWidget.item(line, 2)
                item.setText(_translate("MainWindow", proposta.ans))
                item.setBackground(QtGui.QColor('red'))
                item = self.tableWidget.item(line, 3)
                item.setText(_translate("MainWindow", proposta.filial))
                item.setBackground(QtGui.QColor('red'))
            line = line + 1

        self.tableWidget.setSortingEnabled(__sortingEnabled)
        self.pushValidar.setText(_translate("MainWindow", "Remover propostas pendentes"))
        self.pushEnviar.setText(_translate("MainWindow", "Enviar propostas"))
        self.pushCancelar.setText(_translate("MainWindow", "Cancelar operação"))

        self.pushValidar.clicked.connect(self.remover)
        self.pushEnviar.clicked.connect(self.enviar)
        self.pushCancelar.clicked.connect(self.cancelar)

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

